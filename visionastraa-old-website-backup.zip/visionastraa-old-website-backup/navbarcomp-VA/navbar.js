document.getElementById("hamburger").onclick = function () {
    document.getElementById("nav-links").classList.toggle("active");
};
